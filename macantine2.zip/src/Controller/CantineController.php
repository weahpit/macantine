<?php
namespace App\Controller;
use App\Service\Store;
use App\Security\User;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
final class CantineController extends AbstractController {
    public function __construct(private readonly Store $s) {}
    private function actor(): User { $u=$this->getUser();if (!$u instanceof User) { throw $this->createAccessDeniedException(); }return $u; }
    private function permit(array $roles): void { if (!in_array($this->actor()->role,$roles,true)) { throw $this->createAccessDeniedException('Action non autorisée.'); } }
    private function csrf(Request $r,string $action): void { if (!$this->isCsrfTokenValid($action,(string)$r->request->get('_token'))) { throw $this->createAccessDeniedException('Formulaire expiré. Rechargez la page.'); } }
    private function text(Request $r,string $name,int $max=100,bool $required=true): string {
        $v=trim((string)$r->request->get($name,''));
        if (($required && $v==='') || mb_strlen($v)>$max) { throw new \InvalidArgumentException('Champ '.$name.' manquant ou trop long.'); }
        return $v;
    }
    private function fail(\Throwable $e): void {
        if ($e instanceof \InvalidArgumentException || $e instanceof \DomainException) { $this->addFlash('error',$e->getMessage()); }
        elseif ($e instanceof \Doctrine\DBAL\Exception\UniqueConstraintViolationException) { $this->addFlash('error','Doublon refusé : cette valeur ou ce ticket existe déjà.'); }
        else { throw $e; }
    }
    #[Route('/connexion',name:'connexion',methods:['GET','POST'])]
    public function login(AuthenticationUtils $auth): Response {
        if ($this->getUser()) { return $this->redirectToRoute('accueil'); }
        return $this->render('connexion.html.twig',['last'=>$auth->getLastUsername(),'error'=>$auth->getLastAuthenticationError()]);
    }
    #[Route('/deconnexion',name:'deconnexion',methods:['POST'])]
    public function logout(): never { throw new \LogicException('Interception par le pare-feu.'); }
    #[Route('/',name:'accueil',methods:['GET'])]
    public function home(): Response {
        if ($this->actor()->role==='ROLE_EMPLOYE') { return $this->redirectToRoute('tickets'); }
        if ($this->actor()->role==='ROLE_AGENT') { return $this->redirectToRoute('controle'); }
        $this->s->expire();$date=$this->s->today();
        $rows=$this->s->db->fetchAllAssociative('SELECT statut,COUNT(*) AS total FROM ticket WHERE date_repas=? GROUP BY statut',[$date]);
        $stats=['DISPONIBLE'=>0,'UTILISE'=>0,'ANNULE'=>0,'EXPIRE'=>0];foreach($rows as $v){$stats[$v['statut']]=(int)$v['total'];}
        $base=$stats['DISPONIBLE']+$stats['UTILISE'];
        return $this->render('accueil.html.twig',['date'=>$date,'stats'=>$stats,'taux'=>$base?round(100*$stats['UTILISE']/$base,1):0]);
    }
    #[Route('/employes',name:'employes',methods:['GET','POST'])]
    public function employees(Request $r): Response {
        $this->permit(['ROLE_ADMIN','ROLE_RH']);
        if ($r->isMethod('POST')) {
            $this->csrf($r,'employe');
            try {
                $id=$r->request->getInt('id');$service=$r->request->getInt('service_id');
                if (!$this->s->db->fetchOne('SELECT id FROM service WHERE id=?',[$service])) { throw new \InvalidArgumentException('Choisissez un service existant.'); }
                $data=['matricule'=>$this->text($r,'matricule',50),'nom'=>$this->text($r,'nom',100),'prenoms'=>$this->text($r,'prenoms',150),'service_id'=>$service,'actif'=>$r->request->get('actif')?1:0];
                $this->s->db->transactional(function() use($id,$data){
                    if($id){if(!$this->s->db->fetchOne('SELECT id FROM employe WHERE id=?',[$id])){throw new \InvalidArgumentException('Employé introuvable.');}$this->s->db->update('employe',$data,['id'=>$id]);}
                    else{$data['badge_token']=bin2hex(random_bytes(32));$this->s->db->insert('employe',$data);}
                    $this->s->audit($this->actor()->id,$id?'MODIFICATION_EMPLOYE':'CREATION_EMPLOYE',$data['matricule']);
                });
                $this->addFlash('success','Employé enregistré.');
            } catch (\Throwable $e) { $this->fail($e); }
            return $this->redirectToRoute('employes');
        }
        $edit=$r->query->getInt('modifier');$employee=$edit?$this->s->db->fetchAssociative('SELECT * FROM employe WHERE id=?',[$edit]):null;
        return $this->render('employes.html.twig',['q'=>(string)$r->query->get('q',''),'employes'=>$this->s->employes(trim((string)$r->query->get('q',''))),'services'=>$this->s->db->fetchAllAssociative('SELECT s.*,d.nom AS direction_nom FROM service s JOIN direction d ON d.id=s.direction_id ORDER BY d.nom,s.nom'),'edit'=>$employee]);
    }
    #[Route('/employes/{id}/renouveler-badge',name:'badge_renouveler',methods:['POST'],requirements:['id'=>'\d+'])]
    public function rotateBadge(int $id,Request $r): Response {
        $this->permit(['ROLE_ADMIN','ROLE_RH']);$this->csrf($r,'badge_'.$id);
        $this->s->db->transactional(function()use($id){
            $n=$this->s->db->update('employe',['badge_token'=>bin2hex(random_bytes(32))],['id'=>$id]);
            if(!$n){throw $this->createNotFoundException();}$this->s->audit($this->actor()->id,'RENOUVELLEMENT_BADGE','Employé #'.$id);
        });
        $this->addFlash('success','Nouveau badge créé. L’ancien code est désormais invalide.');return $this->redirectToRoute('badge',['id'=>$id]);
    }
    #[Route('/parametres',name:'parametres',methods:['GET','POST'])]
    public function settings(Request $r): Response {
        $this->permit(['ROLE_ADMIN','ROLE_RH','ROLE_RESPONSABLE']);
        if($r->isMethod('POST')){
            $this->csrf($r,'parametres');
            try{
                $kind=$this->text($r,'nature',30);
                $this->permit($kind==='repas'?['ROLE_ADMIN','ROLE_RESPONSABLE']:['ROLE_ADMIN','ROLE_RH']);
                $this->s->db->transactional(function()use($kind,$r){
                    if($kind==='direction'){$this->s->db->insert('direction',['nom'=>$this->text($r,'nom')]);}
                    elseif($kind==='service'){
                        $d=$r->request->getInt('direction_id');if(!$this->s->db->fetchOne('SELECT id FROM direction WHERE id=?',[$d])){throw new \InvalidArgumentException('Direction invalide.');}
                        $this->s->db->insert('service',['nom'=>$this->text($r,'nom'),'direction_id'=>$d]);
                    }elseif($kind==='repas'){
                        $id=$r->request->getInt('id');$data=['nom'=>$this->text($r,'nom'),'actif'=>$r->request->get('actif')?1:0];
                        if($id){if(!$this->s->db->fetchOne('SELECT id FROM type_repas WHERE id=?',[$id])){throw new \InvalidArgumentException('Repas inconnu.');}$this->s->db->update('type_repas',$data,['id'=>$id]);}else{$this->s->db->insert('type_repas',$data);}
                    }else{throw new \InvalidArgumentException('Paramètre inconnu.');}
                    $this->s->audit($this->actor()->id,'PARAMETRAGE',$kind);
                });$this->addFlash('success','Paramètre enregistré.');
            }catch(\Throwable $e){$this->fail($e);}
            return $this->redirectToRoute('parametres');
        }
        return $this->render('parametres.html.twig',['directions'=>$this->s->db->fetchAllAssociative('SELECT * FROM direction ORDER BY nom'),'services'=>$this->s->db->fetchAllAssociative('SELECT s.*,d.nom AS direction_nom FROM service s JOIN direction d ON d.id=s.direction_id ORDER BY s.nom'),'types'=>$this->s->types()]);
    }
    #[Route('/tickets',name:'tickets',methods:['GET','POST'])]
    public function tickets(Request $r): Response {
        $this->s->expire();$u=$this->actor();
        if($r->isMethod('POST')){
            $this->permit(['ROLE_ADMIN','ROLE_RH']);$this->csrf($r,'emission');
            try{
                $date=$this->s->date($this->text($r,'date_repas',10));$type=$r->request->getInt('type_repas_id');$employee=$r->request->getInt('employe_id');
                $ids=$employee?[$employee]:array_column($this->s->db->fetchAllAssociative('SELECT id FROM employe WHERE actif=1'),'id');$created=0;$skipped=0;
                // Chaque employé est traité séparément pour limiter la durée des transactions.
                foreach($ids as $id){try{$this->s->issue((int)$id,$date,$type,$u->id)?$created++:$skipped++;}catch(\Doctrine\DBAL\Exception\UniqueConstraintViolationException){$skipped++;}}
                $this->addFlash('success',"$created ticket(s) créé(s), $skipped déjà existant(s). Les tickets annulés ne sont pas recréés.");
            }catch(\Throwable $e){$this->fail($e);}
            return $this->redirectToRoute('tickets');
        }
        $date=$r->query->get('date',$this->s->today());$this->s->date((string)$date);$params=[$date];$where='t.date_repas=?';
        if($u->role==='ROLE_EMPLOYE'){$where.=' AND t.employe_id=?';$params[]=$u->employeId??0;}
        $q=trim((string)$r->query->get('q',''));if($q!==''){$where.=' AND (e.nom LIKE ? OR e.matricule LIKE ? OR t.numero LIKE ?)';array_push($params,'%'.$q.'%','%'.$q.'%','%'.$q.'%');}
        $page=max(1,$r->query->getInt('page',1));$offset=($page-1)*50;
        $sql=' FROM ticket t JOIN employe e ON e.id=t.employe_id JOIN type_repas r ON r.id=t.type_repas_id WHERE '.$where;
        $total=(int)$this->s->db->fetchOne('SELECT COUNT(*)'.$sql,$params);
        $rows=$this->s->db->fetchAllAssociative('SELECT t.*,e.nom,e.prenoms,e.matricule,r.nom AS repas_nom'.$sql.' ORDER BY t.id DESC LIMIT 50 OFFSET '.$offset,$params);
        return $this->render('tickets.html.twig',['tickets'=>$rows,'employes'=>in_array($u->role,['ROLE_ADMIN','ROLE_RH'])?$this->s->employes():[],'types'=>$this->s->types(true),'date'=>$date,'q'=>$q,'page'=>$page,'total'=>$total,'today'=>$this->s->today()]);
    }
    #[Route('/tickets/{id}/{action}',name:'ticket_action',methods:['POST'],requirements:['id'=>'\d+','action'=>'annuler|reactiver'])]
    public function ticketAction(int $id,string $action,Request $r): Response {
        $this->permit(['ROLE_ADMIN','ROLE_RH']);$this->csrf($r,'ticket_'.$id);
        $ok=$action==='annuler'?$this->s->cancel($id,$this->actor()->id):$this->s->restore($id,$this->actor()->id);
        $this->addFlash($ok?'success':'error',$ok?'Statut du ticket mis à jour.':'Action refusée : ticket consommé, expiré ou bénéficiaire/repas inactif.');
        return $this->redirectToRoute('tickets');
    }
    #[Route('/controle',name:'controle',methods:['GET','POST'])]
    public function control(Request $r): Response {
        $this->permit(['ROLE_ADMIN','ROLE_AGENT','ROLE_RESPONSABLE']);$ticket=null;$error=null;$input='';$type=0;
        if($r->isMethod('POST')){
            $this->csrf($r,'controle');$input=trim((string)$r->request->get('code',''));$type=$r->request->getInt('type_repas_id');
            if(str_starts_with($input,'CANTINE:T:')){
                $id=$this->s->db->fetchOne('SELECT id FROM ticket WHERE token=?',[substr($input,10)]);$ticket=$id?$this->s->ticket((int)$id):null;
            }elseif(str_starts_with($input,'CANTINE:B:')){
                if(!$type){$error='Sélectionnez le type de repas avant de contrôler un badge.';}
                else{$e=$this->s->db->fetchAssociative('SELECT id,actif FROM employe WHERE badge_token=?',[substr($input,10)]);
                    if(!$e){$error='Badge invalide ou remplacé.';}elseif(!(int)$e['actif']){$error='Employé désactivé.';}else{
                        $id=$this->s->db->fetchOne('SELECT id FROM ticket WHERE employe_id=? AND date_repas=? AND type_repas_id=?',[$e['id'],$this->s->today(),$type]);$ticket=$id?$this->s->ticket((int)$id):null;
                        if(!$ticket){$error='Aucun ticket attribué à cet employé pour ce repas aujourd’hui.';}
                    }
                }
            }else{$id=$this->s->db->fetchOne('SELECT id FROM ticket WHERE numero=?',[$input]);$ticket=$id?$this->s->ticket((int)$id):null;}
            if(!$ticket && !$error){$error='Ticket invalide.';}
            if($ticket){$error=$this->s->validity($ticket);if($type && $type!==(int)$ticket['type_repas_id']){$error='Ce ticket correspond à un autre type de repas.';}}
            if($error){$this->s->audit($this->actor()->id,'CONTROLE_REFUSE',$error);}
        }
        return $this->render('controle.html.twig',['ticket'=>$ticket,'error'=>$error,'types'=>$this->s->types(true),'code'=>$input,'selected'=>$type,'today'=>$this->s->today()]);
    }
    #[Route('/servir/{id}',name:'servir',methods:['POST'],requirements:['id'=>'\d+'])]
    public function serve(int $id,Request $r): Response {
        $this->permit(['ROLE_ADMIN','ROLE_AGENT','ROLE_RESPONSABLE']);$this->csrf($r,'servir_'.$id);
        try{$this->s->consume($id,$this->actor()->id);$this->addFlash('success','Repas enregistré. Le ticket ne peut plus être utilisé, même via le badge.');}
        catch(\DomainException $e){$this->s->audit($this->actor()->id,'VALIDATION_REFUSEE','Ticket #'.$id.' : '.$e->getMessage());$this->addFlash('error',$e->getMessage());}
        return $this->redirectToRoute('controle');
    }
    private function ownTicket(int $id): array {
        $t=$this->s->ticket($id);if(!$t){throw $this->createNotFoundException();}
        if($this->actor()->role==='ROLE_EMPLOYE' && $this->actor()->employeId!==(int)$t['employe_id']){throw $this->createAccessDeniedException();}return $t;
    }
    private function ownBadge(int $id): array {
        $e=$this->s->db->fetchAssociative('SELECT e.*,s.nom AS service_nom FROM employe e JOIN service s ON s.id=e.service_id WHERE e.id=?',[$id]);if(!$e){throw $this->createNotFoundException();}
        if($this->actor()->role==='ROLE_EMPLOYE' && $this->actor()->employeId!==$id){throw $this->createAccessDeniedException();}return $e;
    }
    #[Route('/imprimer/ticket/{id}',name:'imprimer_ticket',methods:['GET'],requirements:['id'=>'\d+'])]
    public function printTicket(int $id): Response { return $this->render('impression.html.twig',['kind'=>'ticket','item'=>$this->ownTicket($id)]); }
    #[Route('/badge/{id}',name:'badge',methods:['GET'],requirements:['id'=>'\d+'])]
    public function badge(int $id): Response { return $this->render('impression.html.twig',['kind'=>'badge','item'=>$this->ownBadge($id)]); }
    #[Route('/qr/{kind}/{id}',name:'qr',methods:['GET'],requirements:['kind'=>'ticket|badge','id'=>'\d+'])]
    public function qr(string $kind,int $id): Response {
        $data=$kind==='ticket'?'CANTINE:T:'.$this->ownTicket($id)['token']:'CANTINE:B:'.$this->ownBadge($id)['badge_token'];
        $qr=new QrCode(data:$data,size:320,margin:16);$result=(new PngWriter())->write($qr);
        return new Response($result->getString(),200,['Content-Type'=>'image/png']);
    }
    #[Route('/menus',name:'menus',methods:['GET','POST'])]
    public function menus(Request $r): Response {
        if($r->isMethod('POST')){
            $this->permit(['ROLE_ADMIN','ROLE_RESPONSABLE']);$this->csrf($r,'menu');
            try{
                $date=$this->s->date($this->text($r,'date_repas',10));$type=$r->request->getInt('type_repas_id');$prix=str_replace(',','.',$this->text($r,'prix',20));
                if(!preg_match('/^\d{1,10}(\.\d{1,2})?$/',$prix)){throw new \InvalidArgumentException('Prix invalide : maximum deux décimales.');}
                if(!$this->s->db->fetchOne('SELECT id FROM type_repas WHERE id=?',[$type])){throw new \InvalidArgumentException('Repas invalide.');}
                $data=['date_repas'=>$date,'type_repas_id'=>$type,'contenu'=>$this->text($r,'contenu',5000),'prix'=>$prix,'observations'=>$this->text($r,'observations',3000,false)];
                $this->s->db->transactional(function()use($data,$date,$type){$id=$this->s->db->fetchOne('SELECT id FROM menu WHERE date_repas=? AND type_repas_id=?',[$date,$type]);if($id){$this->s->db->update('menu',$data,['id'=>$id]);}else{$this->s->db->insert('menu',$data);}$this->s->audit($this->actor()->id,'ENREGISTREMENT_MENU',$date);});
                $this->addFlash('success','Menu enregistré.');
            }catch(\Throwable $e){$this->fail($e);}return $this->redirectToRoute('menus');
        }
        $date=$this->s->date((string)$r->query->get('date',$this->s->today()));
        return $this->render('menus.html.twig',['menus'=>$this->s->db->fetchAllAssociative('SELECT m.*,r.nom AS repas_nom FROM menu m JOIN type_repas r ON r.id=m.type_repas_id WHERE m.date_repas=? ORDER BY r.id',[$date]),'types'=>$this->s->types(true),'date'=>$date]);
    }
    #[Route('/statistiques',name:'statistiques',methods:['GET'])]
    public function stats(Request $r): Response {
        $this->permit(['ROLE_ADMIN','ROLE_RH','ROLE_RESPONSABLE']);
        $start=$this->s->date((string)$r->query->get('debut',substr($this->s->today(),0,7).'-01'));$end=$this->s->date((string)$r->query->get('fin',$this->s->today()));
        if($start>$end){throw new \Symfony\Component\HttpKernel\Exception\BadRequestHttpException('La date de début doit précéder la date de fin.');}
        $groups=[];foreach(['date_repas'=>'Jour','service_nom'=>'Service','direction_nom'=>'Direction','repas_nom'=>'Type de repas'] as $col=>$label){$groups[$label]=$this->s->db->fetchAllAssociative("SELECT $col AS libelle,COUNT(*) AS total FROM consommation WHERE date_repas BETWEEN ? AND ? GROUP BY $col ORDER BY $col",[$start,$end]);}
        return $this->render('statistiques.html.twig',['groups'=>$groups,'debut'=>$start,'fin'=>$end,'total'=>$this->s->db->fetchOne('SELECT COUNT(*) FROM consommation WHERE date_repas BETWEEN ? AND ?',[$start,$end])]);
    }
    #[Route('/utilisateurs',name:'utilisateurs',methods:['GET','POST'])]
    public function users(Request $r,UserPasswordHasherInterface $hasher): Response {
        $this->permit(['ROLE_ADMIN']);
        if($r->isMethod('POST')){
            $this->csrf($r,'utilisateur');
            try{
                $id=$r->request->getInt('id');$email=strtolower($this->text($r,'email',180));$nom=$this->text($r,'nom',150);$role=$this->text($r,'role',30);$active=$r->request->get('actif')?1:0;$employee=$r->request->getInt('employe_id')?:null;
                if(!filter_var($email,FILTER_VALIDATE_EMAIL)){throw new \InvalidArgumentException('Adresse e-mail invalide.');}
                if(!in_array($role,['ROLE_ADMIN','ROLE_RH','ROLE_AGENT','ROLE_RESPONSABLE','ROLE_EMPLOYE'],true)){throw new \InvalidArgumentException('Rôle invalide.');}
                if($employee && !$this->s->db->fetchOne('SELECT id FROM employe WHERE id=?',[$employee])){throw new \InvalidArgumentException('Employé inexistant.');}
                if($role==='ROLE_EMPLOYE' && !$employee){throw new \InvalidArgumentException('Un compte employé doit être lié à un employé.');}
                if($id===$this->actor()->id && (!$active || $role!=='ROLE_ADMIN')){throw new \InvalidArgumentException('Vous ne pouvez pas désactiver votre propre accès administrateur.');}
                if($id && !$this->s->db->fetchOne('SELECT id FROM utilisateur WHERE id=?',[$id])){throw new \InvalidArgumentException('Compte introuvable.');}
                $data=['email'=>$email,'nom'=>$nom,'role'=>$role,'actif'=>$active,'employe_id'=>$employee];$password=(string)$r->request->get('mot_de_passe','');
                if(!$id || $password!==''){
                    if(strlen($password)<12){throw new \InvalidArgumentException('Mot de passe : 12 caractères minimum.');}
                    $data['mot_de_passe']=$hasher->hashPassword(new User(0,$email,'',$role,true,$employee,$nom),$password);
                }
                $this->s->db->transactional(function()use($id,$data,$email){if($id){$this->s->db->update('utilisateur',$data,['id'=>$id]);}else{$this->s->db->insert('utilisateur',$data);}$this->s->audit($this->actor()->id,'ENREGISTREMENT_COMPTE',$email);});$this->addFlash('success','Compte enregistré.');
            }catch(\Throwable $e){$this->fail($e);}return $this->redirectToRoute('utilisateurs');
        }
        $id=$r->query->getInt('modifier');return $this->render('utilisateurs.html.twig',['users'=>$this->s->db->fetchAllAssociative('SELECT id,email,nom,role,actif,employe_id FROM utilisateur ORDER BY nom'),'employes'=>$this->s->employes(),'edit'=>$id?$this->s->db->fetchAssociative('SELECT id,email,nom,role,actif,employe_id FROM utilisateur WHERE id=?',[$id]):null]);
    }
    #[Route('/journal',name:'journal',methods:['GET'])]
    public function audit(Request $r): Response {
        $this->permit(['ROLE_ADMIN']);$page=max(1,$r->query->getInt('page',1));
        return $this->render('journal.html.twig',['rows'=>$this->s->db->fetchAllAssociative('SELECT a.*,u.nom AS agent_nom FROM audit a LEFT JOIN utilisateur u ON u.id=a.utilisateur_id ORDER BY a.id DESC LIMIT 100 OFFSET '.(($page-1)*100)),'page'=>$page]);
    }
}
