<?php
namespace App\Service;
use Doctrine\DBAL\Connection;
final class Store {
    public function __construct(public readonly Connection $db, private readonly string $timezone) {}
    public function now(): string { return (new \DateTimeImmutable('now',new \DateTimeZone($this->timezone)))->format('Y-m-d H:i:s'); }
    public function today(): string { return substr($this->now(),0,10); }
    public function date(string $value): string {
        $d=\DateTimeImmutable::createFromFormat('!Y-m-d',$value);
        if (!$d || $d->format('Y-m-d') !== $value) { throw new \InvalidArgumentException('Date invalide.'); }
        return $value;
    }
    public function audit(?int $user, string $action, string $detail=''): void {
        $this->db->insert('audit',['utilisateur_id'=>$user,'action'=>$action,'detail'=>$detail,'cree_le'=>$this->now()]);
    }
    public function expire(): void {
        $this->db->executeStatement("UPDATE ticket SET statut='EXPIRE' WHERE statut='DISPONIBLE' AND date_repas < ?",[$this->today()]);
    }
    public function employes(string $q=''): array {
        $sql='SELECT e.*,s.nom AS service_nom,d.nom AS direction_nom FROM employe e JOIN service s ON s.id=e.service_id JOIN direction d ON d.id=s.direction_id';
        $params=[];if($q!==''){$sql.=' WHERE e.matricule LIKE ? OR e.nom LIKE ? OR e.prenoms LIKE ?';$params=['%'.$q.'%','%'.$q.'%','%'.$q.'%'];}
        return $this->db->fetchAllAssociative($sql.' ORDER BY e.nom,e.prenoms',$params);
    }
    public function types(bool $actifs=false): array { return $this->db->fetchAllAssociative('SELECT * FROM type_repas'.($actifs?' WHERE actif=1':'').' ORDER BY id'); }
    public function ticket(int $id): array|false {
        return $this->db->fetchAssociative('SELECT t.*,e.matricule,e.nom,e.prenoms,e.actif AS employe_actif,s.nom AS service_nom,d.nom AS direction_nom,r.nom AS repas_nom,r.actif AS repas_actif FROM ticket t JOIN employe e ON e.id=t.employe_id JOIN service s ON s.id=e.service_id JOIN direction d ON d.id=s.direction_id JOIN type_repas r ON r.id=t.type_repas_id WHERE t.id=?',[$id]);
    }
    public function validity(array $t): ?string {
        if ($t['statut']==='UTILISE') { return 'Ticket déjà utilisé.'; }
        if ($t['statut']==='ANNULE') { return 'Ticket annulé.'; }
        if ($t['statut']==='EXPIRE' || $t['date_repas'] < $this->today()) { return 'Ticket expiré.'; }
        if ($t['date_repas'] > $this->today()) { return 'Ticket prévu pour une autre date.'; }
        if (!(int)$t['employe_actif']) { return 'Employé désactivé.'; }
        if (!(int)$t['repas_actif']) { return 'Type de repas désactivé.'; }
        if ($t['statut']!=='DISPONIBLE') { return 'Ticket non disponible.'; }
        return null;
    }
    public function issue(int $employe, string $date, int $type, int $agent): bool {
        $this->date($date);
        if ($date<$this->today()) { throw new \InvalidArgumentException('Impossible de créer un ticket pour une date passée.'); }
        if (!$this->db->fetchOne('SELECT id FROM employe WHERE id=? AND actif=1',[$employe])) { throw new \InvalidArgumentException('Employé inexistant ou désactivé.'); }
        if (!$this->db->fetchOne('SELECT id FROM type_repas WHERE id=? AND actif=1',[$type])) { throw new \InvalidArgumentException('Type de repas inexistant ou désactivé.'); }
        return $this->db->transactional(function () use ($employe,$date,$type,$agent) {
            if ($this->db->fetchOne('SELECT id FROM ticket WHERE employe_id=? AND date_repas=? AND type_repas_id=?',[$employe,$date,$type])) { return false; }
            $token=bin2hex(random_bytes(32));
            $number='CTR-'.str_replace('-','',$date).'-'.strtoupper(bin2hex(random_bytes(6)));
            $this->db->insert('ticket',['numero'=>$number,'token'=>$token,'employe_id'=>$employe,'date_repas'=>$date,'type_repas_id'=>$type,'statut'=>'DISPONIBLE','cree_le'=>$this->now(),'cree_par'=>$agent]);
            $this->audit($agent,'CREATION_TICKET',$number);
            return true;
        });
    }
    public function cancel(int $id,int $agent): bool {
        return $this->db->transactional(function () use ($id,$agent) {
            $n=$this->db->executeStatement("UPDATE ticket SET statut='ANNULE' WHERE id=? AND statut='DISPONIBLE'",[$id]);
            if ($n) { $this->audit($agent,'ANNULATION_TICKET','Ticket #'.$id); }
            return $n===1;
        });
    }
    public function restore(int $id,int $agent): bool {
        return $this->db->transactional(function () use ($id,$agent) {
            $n=$this->db->executeStatement("UPDATE ticket SET statut='DISPONIBLE' WHERE id=? AND statut='ANNULE' AND date_repas>=? AND employe_id IN (SELECT id FROM employe WHERE actif=1) AND type_repas_id IN (SELECT id FROM type_repas WHERE actif=1)",[$id,$this->today()]);
            if ($n) { $this->audit($agent,'REACTIVATION_TICKET','Ticket #'.$id); }
            return $n===1;
        });
    }
    public function consume(int $id,int $agent): void {
        $this->db->transactional(function () use ($id,$agent) {
            // Cette mise à jour conditionnelle verrouille la même ligne pour badge et ticket.
            $n=$this->db->executeStatement("UPDATE ticket SET statut='UTILISE' WHERE id=? AND statut='DISPONIBLE' AND date_repas=? AND employe_id IN (SELECT id FROM employe WHERE actif=1) AND type_repas_id IN (SELECT id FROM type_repas WHERE actif=1)",[$id,$this->today()]);
            if ($n!==1) {
                $t=$this->ticket($id);
                throw new \DomainException($t ? ($this->validity($t) ?? 'Validation concurrente refusée. Veuillez rescanner.') : 'Ticket invalide.');
            }
            $t=$this->ticket($id);
            $this->db->insert('consommation',['ticket_id'=>$id,'employe_id'=>$t['employe_id'],'type_repas_id'=>$t['type_repas_id'],'date_repas'=>$t['date_repas'],'servi_le'=>$this->now(),'agent_id'=>$agent,'matricule'=>$t['matricule'],'employe_nom'=>$t['nom'].' '.$t['prenoms'],'service_nom'=>$t['service_nom'],'direction_nom'=>$t['direction_nom'],'repas_nom'=>$t['repas_nom']]);
            $this->audit($agent,'VALIDATION_REPAS',$t['numero']);
        });
    }
}
