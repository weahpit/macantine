<?php
namespace App\Security;
use App\Service\Store;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Exception\UserNotFoundException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
/** @implements UserProviderInterface<User> */
final class UserProvider implements UserProviderInterface {
    public function __construct(private readonly Store $store) {}
    public function loadUserByIdentifier(string $identifier): User {
        $r=$this->store->db->fetchAssociative('SELECT * FROM utilisateur WHERE email=?',[strtolower(trim($identifier))]);
        if (!$r) { $e=new UserNotFoundException();$e->setUserIdentifier($identifier);throw $e; }
        return new User((int)$r['id'],$r['email'],$r['mot_de_passe'],$r['role'],(bool)$r['actif'],$r['employe_id']!==null?(int)$r['employe_id']:null,$r['nom']);
    }
    public function refreshUser(UserInterface $user): UserInterface {
        if (!$user instanceof User) { throw new UnsupportedUserException(); }
        return $this->loadUserByIdentifier($user->getUserIdentifier());
    }
    public function supportsClass(string $class): bool { return $class===User::class; }
}
